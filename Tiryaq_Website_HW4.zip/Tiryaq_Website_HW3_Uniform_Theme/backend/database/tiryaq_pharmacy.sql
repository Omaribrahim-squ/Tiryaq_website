
-- Step 1: Create the database
CREATE DATABASE tiryaq_pharmacy;

-- Step 2: Use the database
USE tiryaq_pharmacy;

-- Step 3: Create ContactForm table
CREATE TABLE ContactForm (
  id INT PRIMARY KEY,
  name VARCHAR(50),
  email VARCHAR(100),
  phone VARCHAR(20),
  message TEXT
);

-- Step 4: Insert sample data into ContactForm
INSERT INTO ContactForm VALUES (1, 'Ali Ahmed', 'ali@example.com', '912345678', 'I need help with my order.');
INSERT INTO ContactForm VALUES (2, 'Fatima Noor', 'fatima@example.com', '933334567', 'Do you have Vitamin D?');
INSERT INTO ContactForm VALUES (3, 'Salem Nasser', 'salem@example.com', '944448888', 'The product arrived damaged.');
INSERT INTO ContactForm VALUES (4, 'Laila Hussein', 'laila@example.com', '955556789', 'Can I return my purchase?');
INSERT INTO ContactForm VALUES (5, 'Hamad Saleh', 'hamad@example.com', '966667890', 'Thanks for the fast delivery.');

-- Step 5: Create Feedback table
CREATE TABLE Feedback (
  id INT PRIMARY KEY,
  name VARCHAR(50),
  age_group VARCHAR(20),
  rating VARCHAR(10),
  comments TEXT
);

-- Step 6: Insert sample data into Feedback
INSERT INTO Feedback VALUES (1, 'Ali Ahmed', '18-30', 'Good', 'Very satisfied with the service.');
INSERT INTO Feedback VALUES (2, 'Fatima Noor', '31-50', 'Average', 'It was okay.');
INSERT INTO Feedback VALUES (3, 'Salem Nasser', '18-30', 'Poor', 'Not happy with the packaging.');
INSERT INTO Feedback VALUES (4, 'Laila Hussein', 'Above 50', 'Good', 'Fast response and kind staff.');
INSERT INTO Feedback VALUES (5, 'Hamad Saleh', 'Under 18', 'Good', 'Easy to use website.');

-- Step 7: Create Product table
CREATE TABLE Product (
  id INT PRIMARY KEY,
  product_name VARCHAR(100),
  price DECIMAL(5,2),
  description TEXT
);

-- Step 8: Insert sample data into Product
INSERT INTO Product VALUES (1, 'Panadol', 1.50, 'Pain relief tablet');
INSERT INTO Product VALUES (2, 'Vitamin C', 2.00, 'Immune support supplement');
INSERT INTO Product VALUES (3, 'Cough Syrup', 3.25, 'Soothes sore throat');
INSERT INTO Product VALUES (4, 'Allergy Tablets', 2.75, 'For allergy symptoms');
INSERT INTO Product VALUES (5, 'Face Mask Pack', 5.00, 'Pack of 50 surgical masks');
