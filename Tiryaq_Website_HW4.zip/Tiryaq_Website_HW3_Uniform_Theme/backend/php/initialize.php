<?php
require_once 'db_config.php';

echo "<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <title>Database Initialization</title>
    <style>
        body { font-family: Arial; padding: 20px; background-color: #f5f5f5; }
        .message { background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; border: 1px solid #c3e6cb; }
    </style>
</head>
<body>
    <div class='message'>
        ✅ Database and products initialized successfully.
    </div>
</body>
</html>";
?>
