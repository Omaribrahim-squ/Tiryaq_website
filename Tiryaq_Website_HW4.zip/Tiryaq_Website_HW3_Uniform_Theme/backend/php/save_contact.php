
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Contact Form Submission</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
  <h2 class="text-center mb-4">Contact Form Result</h2>
  <?php
    // 1. Receive form data
    $name = $_POST["name"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $message = $_POST["message"];

    // 2. Connect to the database
    $conn = mysqli_connect("localhost", "root", "", "tiryaq_pharmacy");

    // 3. Check connection
    if (!$conn) {
      die("<p class='text-danger'>Connection failed: " . mysqli_connect_error() . "</p>");
    }

    // 4. Create SQL to insert data
    $sql = "INSERT INTO ContactForm (id, name, email, phone, message)
            VALUES (NULL, '$name', '$email', '$phone', '$message')";

    // 5. Execute query
    if (mysqli_query($conn, $sql)) {
      echo "<p class='text-success'>Thank you $name. Your message has been received!</p>";
    } else {
      echo "<p class='text-danger'>Error: " . mysqli_error($conn) . "</p>";
    }

    // 6. Close connection
    mysqli_close($conn);
  ?>
</div>
</body>
</html>
