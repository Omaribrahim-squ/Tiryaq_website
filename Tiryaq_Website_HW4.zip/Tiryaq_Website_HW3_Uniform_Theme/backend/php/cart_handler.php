<?php
// /home/ubuntu/tiryaq_pharmacy/backend/php/cart_handler.php
require_once 'db_config.php'; // To potentially fetch product details if needed

session_start();

// Initialize cart if it doesn't exist
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

header('Content-Type: application/json');
$action = $_POST['action'] ?? $_GET['action'] ?? null;
$response = ['success' => false, 'message' => 'Invalid action.', 'cart' => $_SESSION['cart']];

switch ($action) {
    case 'add':
        $product_id = filter_var($_POST['product_id'] ?? null, FILTER_VALIDATE_INT);
        $quantity = filter_var($_POST['quantity'] ?? 1, FILTER_VALIDATE_INT);

        if ($product_id && $quantity > 0) {
            try {
                $stmt = $pdo->prepare("SELECT id, name, price, image_url FROM products WHERE id = :id");
                $stmt->bindParam(':id', $product_id, PDO::PARAM_INT);
                $stmt->execute();
                $product = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($product) {
                    if (isset($_SESSION['cart'][$product_id])) {
                        $_SESSION['cart'][$product_id]['quantity'] += $quantity;
                    } else {
                        $_SESSION['cart'][$product_id] = [
                            'id' => $product_id,
                            'name' => $product['name'],
                            'price' => (float)$product['price'],
                            'quantity' => $quantity,
                            'image_url' => $product['image_url']
                        ];
                    }
                    $response = ['success' => true, 'message' => 'Product added to cart.', 'cart' => $_SESSION['cart']];
                } else {
                    $response['message'] = 'Product not found.';
                }
            } catch (PDOException $e) {
                $response['message'] = 'Database error: ' . $e->getMessage();
            }
        } else {
            $response['message'] = 'Invalid product ID or quantity.';
        }
        break;

    case 'update':
        $product_id = filter_var($_POST['product_id'] ?? null, FILTER_VALIDATE_INT);
        $quantity = filter_var($_POST['quantity'] ?? 0, FILTER_VALIDATE_INT);

        if ($product_id) {
            if (isset($_SESSION['cart'][$product_id])) {
                if ($quantity > 0) {
                    $_SESSION['cart'][$product_id]['quantity'] = $quantity;
                    $response = ['success' => true, 'message' => 'Cart updated.', 'cart' => $_SESSION['cart']];
                } else { // Quantity is 0 or less, so remove the item
                    unset($_SESSION['cart'][$product_id]);
                    $response = ['success' => true, 'message' => 'Product removed from cart.', 'cart' => $_SESSION['cart']];
                }
            } else {
                $response['message'] = 'Product not in cart.';
            }
        } else {
            $response['message'] = 'Invalid product ID.';
        }
        break;

    case 'remove':
        $product_id = filter_var($_POST['product_id'] ?? null, FILTER_VALIDATE_INT);
        if ($product_id) {
            if (isset($_SESSION['cart'][$product_id])) {
                unset($_SESSION['cart'][$product_id]);
                $response = ['success' => true, 'message' => 'Product removed from cart.', 'cart' => $_SESSION['cart']];
            } else {
                $response['message'] = 'Product not in cart.';
            }
        } else {
            $response['message'] = 'Invalid product ID.';
        }
        break;

    case 'get':
        $response = ['success' => true, 'message' => 'Cart data fetched.', 'cart' => array_values($_SESSION['cart'])]; // Return as indexed array for easier JS iteration
        break;

    case 'clear':
        $_SESSION['cart'] = [];
        $response = ['success' => true, 'message' => 'Cart cleared.', 'cart' => $_SESSION['cart']];
        break;

    default:
        // Response already set to 'Invalid action.'
        break;
}

echo json_encode($response);
exit;
?>
