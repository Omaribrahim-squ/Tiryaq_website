<?php 
require_once 'db_config.php'; 
$message = '';
$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = trim($_POST['price'] ?? '');
    $image_url = trim($_POST['image_url'] ?? '');

    // Basic validation
    if (empty($name) || empty($price) || empty($image_url)) {
        $error = "Name, Price, and Image URL are required fields.";
    } elseif (!is_numeric($price) || $price < 0) {
        $error = "Price must be a non-negative number.";
    } elseif (!filter_var('http://dummy.com/' . $image_url, FILTER_VALIDATE_URL) && !preg_match('/^[a-zA-Z0-9_\\-\\.]+\\.(png|jpg|jpeg|gif|webp)$/i', $image_url) && !preg_match('/^images\\/[a-zA-Z0-9_\\-\\.]+\\.(png|jpg|jpeg|gif|webp)$/i', $image_url)) {
        // A more flexible check for image_url, allowing relative paths like 'images/product.png' or just 'product.png'
        // The dummy.com part is to make filter_var work for relative paths, it's not ideal but common for basic checks.
        // A better approach for production would be more robust validation or specific path requirements.
        if (!preg_match('/^(images\/)?[a-zA-Z0-9_\-\.]+\.(png|jpg|jpeg|gif|webp)$/i', $image_url)){
             $error = "Image URL must be a valid image file path (e.g., images/image.png or image.jpg).";
        }
    }

    if (empty($error)) {
        try {
            $sql = "INSERT INTO products (name, category, description, price, image_url) VALUES (:name, :category, :description, :price, :image_url)";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':name', $name);
            $stmt->bindParam(':category', $category);
            $stmt->bindParam(':description', $description);
            $stmt->bindParam(':price', $price);
            $stmt->bindParam(':image_url', $image_url); // Store as provided, assuming it's relative to frontend/images/
            
            $stmt->execute();
            $message = "Product added successfully! ID: " . $pdo->lastInsertId();
        } catch (PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>Add New Product - Tiryaq Pharmacy Backend</title>
    <!-- Bootstrap CSS for styling -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style type="text/css">
        body { 
            padding-top: 70px; /* Adjust for fixed navbar */ 
            font-family: Arial, sans-serif;
        }
        .container { max-width: 700px; }
        .navbar-brand { font-weight: bold; }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="../../products.html">Tiryaq Pharmacy (Frontend)</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavBackend" aria-controls="navbarNavBackend" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavBackend">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="search.php">Search Products</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="insert_product.php">Add Product</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="update_product_selection.php">Update Product</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <h2 class="text-center mb-4">Add New Product</h2>

        <?php if ($message): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <form action="insert_product.php" method="post" class="p-3 border rounded bg-light">
            <div class="mb-3">
                <label for="name" class="form-label">Product Name: <span style="color:red;">*</span></label>
                <input type="text" id="name" name="name" class="form-control" required="required" value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>" />
            </div>
            <div class="mb-3">
                <label for="category" class="form-label">Category:</label>
                <input type="text" id="category" name="category" class="form-control" value="<?php echo htmlspecialchars($_POST['category'] ?? ''); ?>" />
            </div>
            <div class="mb-3">
                <label for="description" class="form-label">Description:</label>
                <textarea id="description" name="description" class="form-control" rows="3"><?php echo htmlspecialchars($_POST['description'] ?? ''); ?></textarea>
            </div>
            <div class="mb-3">
                <label for="price" class="form-label">Price (OMR): <span style="color:red;">*</span></label>
                <input type="number" step="0.01" id="price" name="price" class="form-control" required="required" value="<?php echo htmlspecialchars($_POST['price'] ?? ''); ?>" />
            </div>
            <div class="mb-3">
                <label for="image_url" class="form-label">Image URL (e.g., images/product.png): <span style="color:red;">*</span></label>
                <input type="text" id="image_url" name="image_url" class="form-control" required="required" value="<?php echo htmlspecialchars($_POST['image_url'] ?? ''); ?>" placeholder="images/example.png" />
                 <small class="form-text text-muted">Path relative to the main `tiryaq_pharmacy` folder, e.g., `images/your_image.png`.</small>
            </div>
            <button type="submit" class="btn btn-primary">Add Product</button>
        </form>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
