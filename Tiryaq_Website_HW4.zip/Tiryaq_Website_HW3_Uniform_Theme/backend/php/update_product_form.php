<?php 
require_once 'db_config.php'; 
$message = '';
$error = '';
$product = null;
$product_id = null;

if (isset($_GET['id'])) {
    $product_id = filter_var($_GET['id'], FILTER_VALIDATE_INT);
    if ($product_id === false || $product_id <= 0) {
        $error = "Invalid Product ID provided.";
    } else {
        try {
            $stmt = $pdo->prepare("SELECT * FROM products WHERE id = :id");
            $stmt->bindParam(':id', $product_id, PDO::PARAM_INT);
            $stmt->execute();
            $product = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$product) {
                $error = "Product not found.";
                $product_id = null; // Reset ID if product not found
            }
        } catch (PDOException $e) {
            $error = "Database error fetching product: " . $e->getMessage();
            $product_id = null;
        }
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $posted_id = filter_var($_POST['id'] ?? '', FILTER_VALIDATE_INT);
    $name = trim($_POST['name'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = trim($_POST['price'] ?? '');
    $image_url = trim($_POST['image_url'] ?? '');

    if ($posted_id === false || $posted_id <= 0) {
        $error = "Invalid Product ID submitted.";
    } elseif (empty($name) || empty($price) || empty($image_url)) {
        $error = "Name, Price, and Image URL are required fields.";
    } elseif (!is_numeric($price) || $price < 0) {
        $error = "Price must be a non-negative number.";
    } elseif (!preg_match('/^(images\/)?[a-zA-Z0-9_\-\.]+\.(png|jpg|jpeg|gif|webp)$/i', $image_url)) {
        $error = "Image URL must be a valid image file path (e.g., images/image.png or image.jpg).";
    }

    if (empty($error) && $posted_id) {
        try {
            $sql = "UPDATE products SET name = :name, category = :category, description = :description, price = :price, image_url = :image_url WHERE id = :id";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':name', $name);
            $stmt->bindParam(':category', $category);
            $stmt->bindParam(':description', $description);
            $stmt->bindParam(':price', $price);
            $stmt->bindParam(':image_url', $image_url);
            $stmt->bindParam(':id', $posted_id, PDO::PARAM_INT);
            
            $stmt->execute();
            $message = "Product updated successfully!";
            // Re-fetch product to display updated data
            $stmt_refetch = $pdo->prepare("SELECT * FROM products WHERE id = :id");
            $stmt_refetch->bindParam(':id', $posted_id, PDO::PARAM_INT);
            $stmt_refetch->execute();
            $product = $stmt_refetch->fetch(PDO::FETCH_ASSOC);
            $product_id = $posted_id; // Ensure product_id is set for the form display

        } catch (PDOException $e) {
            $error = "Database error updating product: " . $e->getMessage();
        }
    } elseif ($posted_id) { // If there was an error, but we have an ID, try to re-fetch for form display
        try {
            $stmt = $pdo->prepare("SELECT * FROM products WHERE id = :id");
            $stmt->bindParam(':id', $posted_id, PDO::PARAM_INT);
            $stmt->execute();
            $product = $stmt->fetch(PDO::FETCH_ASSOC);
            $product_id = $posted_id;
        } catch (PDOException $e) {
            // Error already set or will be handled by initial fetch logic
        }
    }
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>Update Product - Tiryaq Pharmacy Backend</title>
    <!-- Bootstrap CSS for styling -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style type="text/css">
        body { 
            padding-top: 70px; /* Adjust for fixed navbar */ 
            font-family: Arial, sans-serif;
        }
        .container { max-width: 700px; }
        .navbar-brand { font-weight: bold; }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="../../products.html">Tiryaq Pharmacy (Frontend)</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavBackend" aria-controls="navbarNavBackend" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavBackend">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="search.php">Search Products</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="insert_product.php">Add Product</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="update_product_selection.php">Update Product</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <h2 class="text-center mb-4">Update Product</h2>

        <?php if ($message): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($product): ?>
            <form action="update_product_form.php?id=<?php echo htmlspecialchars($product_id); ?>" method="post" class="p-3 border rounded bg-light">
                <input type="hidden" name="id" value="<?php echo htmlspecialchars($product['id']); ?>" />
                <div class="mb-3">
                    <label for="name" class="form-label">Product Name: <span style="color:red;">*</span></label>
                    <input type="text" id="name" name="name" class="form-control" required="required" value="<?php echo htmlspecialchars($product['name'] ?? ($_POST['name'] ?? '')); ?>" />
                </div>
                <div class="mb-3">
                    <label for="category" class="form-label">Category:</label>
                    <input type="text" id="category" name="category" class="form-control" value="<?php echo htmlspecialchars($product['category'] ?? ($_POST['category'] ?? '')); ?>" />
                </div>
                <div class="mb-3">
                    <label for="description" class="form-label">Description:</label>
                    <textarea id="description" name="description" class="form-control" rows="3"><?php echo htmlspecialchars($product['description'] ?? ($_POST['description'] ?? '')); ?></textarea>
                </div>
                <div class="mb-3">
                    <label for="price" class="form-label">Price (OMR): <span style="color:red;">*</span></label>
                    <input type="number" step="0.01" id="price" name="price" class="form-control" required="required" value="<?php echo htmlspecialchars($product['price'] ?? ($_POST['price'] ?? '')); ?>" />
                </div>
                <div class="mb-3">
                    <label for="image_url" class="form-label">Image URL (e.g., images/product.png): <span style="color:red;">*</span></label>
                    <input type="text" id="image_url" name="image_url" class="form-control" required="required" value="<?php echo htmlspecialchars($product['image_url'] ?? ($_POST['image_url'] ?? '')); ?>" placeholder="images/example.png" />
                    <small class="form-text text-muted">Path relative to the main `tiryaq_pharmacy` folder, e.g., `images/your_image.png`.</small>
                </div>
                <button type="submit" class="btn btn-primary">Update Product</button>
                <a href="update_product_selection.php" class="btn btn-secondary">Cancel / Select Another</a>
            </form>
        <?php elseif (!$error): // No product ID in GET or product not found, but no other error yet ?>
            <div class="alert alert-warning">Please <a href="update_product_selection.php">select a product</a> to update.</div>
        <?php endif; ?>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
