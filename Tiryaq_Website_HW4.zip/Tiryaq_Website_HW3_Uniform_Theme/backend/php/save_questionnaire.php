<?php
require_once('../database/db.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"] ?? '';
    $age_group = $_POST["age_group"] ?? '';
    $rating = $_POST["rating"] ?? '';
    $comments = $_POST["comments"] ?? '';

    $sql = "INSERT INTO Feedback (id, name, age_group, rating, comments)
            VALUES (NULL, '$name', '$age_group', '$rating', '$comments')";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Feedback Submission</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
  <h2 class="text-center mb-4">Feedback Submission Result</h2>
  <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (mysqli_query($conn, $sql)) {
            echo "<p class='text-success'>Thank you $name for your feedback!</p>";
        } else {
            echo "<p class='text-danger'>Error: " . mysqli_error($conn) . "</p>";
        }
    } else {
        echo "<p class='text-warning'>Please submit the form properly.</p>";
    }
  ?>
</div>
</body>
</html>
