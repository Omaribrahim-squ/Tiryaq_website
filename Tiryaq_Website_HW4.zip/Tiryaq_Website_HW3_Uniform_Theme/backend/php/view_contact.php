<?php
require_once('../database/db.php');

$search = $_GET['search'] ?? '';
$query = "SELECT * FROM contactform WHERE 
          name LIKE '%$search%' OR 
          email LIKE '%$search%' OR 
          phone LIKE '%$search%' OR 
          message LIKE '%$search%'";

$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>All Contact Messages</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2 class="mb-4 text-center">All Contact Messages</h2>

    <form class="d-flex mb-4" method="GET">
        <input class="form-control me-2" type="search" name="search" placeholder="Search messages..." value="<?= htmlspecialchars($search) ?>">
        <button class="btn btn-primary" type="submit">Search</button>
        <a href="view_contact.php" class="btn btn-secondary ms-2">Reset</a>
        <a href="../../contact.html" class="btn btn-outline-info ms-2">Back to Contact Page</a>
    </form>

    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Message</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['id']) ?></td>
                <td><?= htmlspecialchars($row['name']) ?></td>
                <td><?= htmlspecialchars($row['email']) ?></td>
                <td><?= htmlspecialchars($row['phone']) ?></td>
                <td><?= htmlspecialchars($row['message']) ?></td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>
</body>
</html>
