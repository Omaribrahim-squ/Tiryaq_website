<?php
// db_config.php - SQLite setup and database seeding

$pdo = null;

try {
    // Full absolute path to the SQLite database file
    $db_path = __DIR__ . '/../database/tiryaq_pharmacy.db';

    // Ensure the directory exists
    if (!is_dir(dirname($db_path))) {
        mkdir(dirname($db_path), 0755, true);
    }

    // Connect to the database
    $pdo = new PDO('sqlite:' . $db_path);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $e) {
    die("❌ Could not connect to the database: " . $e->getMessage());
}

// Function to create and seed the products table
function initializeDatabase($pdo_conn, $products_data_array) {
    try {
        // Create table if it doesn't exist
        $pdo_conn->exec("CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            category TEXT,
            description TEXT,
            price REAL NOT NULL,
            image_url TEXT
        )");

        // Seed data if table is empty
        $stmt = $pdo_conn->query("SELECT COUNT(*) FROM products");
        if ($stmt->fetchColumn() == 0) {
            $insert_sql = "INSERT INTO products (name, category, description, price, image_url)
                           VALUES (:name, :category, :description, :price, :image_url)";
            $stmt_insert = $pdo_conn->prepare($insert_sql);

            foreach ($products_data_array as $product) {
                $stmt_insert->bindParam(':name', $product['name']);
                $stmt_insert->bindParam(':category', $product['category']);
                $stmt_insert->bindParam(':description', $product['description']);
                $stmt_insert->bindParam(':price', $product['price']);
                $stmt_insert->bindParam(':image_url', $product['image_url']);
                $stmt_insert->execute();
            }
        }

    } catch (PDOException $e) {
        die("❌ Database initialization failed: " . $e->getMessage());
    }
}

// Seed products
$products_to_seed = [
    ["name" => "Paracetamol", "category" => "Pain Relief", "description" => "Pain reliever and fever reducer.", "price" => 2.70, "image_url" => "images/Paracetamol.png"],
    ["name" => "Metformin", "category" => "Diabetes Care", "description" => "Treat high blood sugar levels.", "price" => 3.50, "image_url" => "images/Metformin.png"],
    ["name" => "Levothyroxine Sodium", "category" => "Thyroid Medication", "description" => "For underactive thyroid gland problem.", "price" => 1.60, "image_url" => "images/Levothyroxine Sodium.png"],
    ["name" => "Lisinopril", "category" => "Blood Pressure", "description" => "High blood pressure (hypertension).", "price" => 2.85, "image_url" => "images/Lisinopril.png"],
    ["name" => "Atorvastatin", "category" => "Cholesterol Management", "description" => "Lower cholesterol and triglyceride (fats) levels in the blood.", "price" => 4.00, "image_url" => "images/Atorvastatin.png"],
    ["name" => "Esomeprazole", "category" => "Digestive Health", "description" => "For too much acid in the stomach.", "price" => 3.10, "image_url" => "images/esomeprazole.png"],
    ["name" => "Loratadine", "category" => "Allergy Relief", "description" => "Treat allergy symptoms.", "price" => 3.70, "image_url" => "images/Loratadine.png"],
    ["name" => "Salbutamol", "category" => "Respiratory Care", "description" => "Relieve symptoms of asthma and chronic obstructive pulmonary disease.", "price" => 1.90, "image_url" => "images/Salbutamol.png"],
    ["name" => "Amoxicillin bp 500mg", "category" => "Antibiotics", "description" => "Treat bacterial infections.", "price" => 4.20, "image_url" => "images/Amoxicillin.png"]
];

// Run the initialization
if ($pdo) {
    initializeDatabase($pdo, $products_to_seed);
}
?>
