<?php require_once 'db_config.php'; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>Search Products - Tiryaq Pharmacy Backend</title>
    <!-- Bootstrap CSS for styling -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style type="text/css">
        body {
            padding-top: 70px; /* Adjust for fixed navbar */
            font-family: Arial, sans-serif;
        }
        .container {
            max-width: 900px;
        }
        table img {
            max-width: 100px;
            height: auto;
        }
        .navbar-brand {
            font-weight: bold;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="../../products.html">Tiryaq Pharmacy (Frontend)</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavBackend" aria-controls="navbarNavBackend" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavBackend">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="search.php">Search Products</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="insert_product.php">Add Product</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="update_product_selection.php">Update Product</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <h2 class="text-center mb-4">Search Products</h2>

        <form action="search.php" method="get" class="mb-4 p-3 border rounded bg-light">
            <div class="row g-3">
                <div class="col-md-6">
                    <label for="search_name" class="form-label">Product Name:</label>
                    <input type="text" id="search_name" name="search_name" class="form-control" value="<?php echo htmlspecialchars($_GET['search_name'] ?? ''); ?>" />
                </div>
                <div class="col-md-6">
                    <label for="search_category" class="form-label">Category:</label>
                    <input type="text" id="search_category" name="search_category" class="form-control" value="<?php echo htmlspecialchars($_GET['search_category'] ?? ''); ?>" />
                </div>
            </div>
            <div class="row g-3 mt-2">
                <div class="col-md-4">
                    <label for="min_price" class="form-label">Min Price (OMR):</label>
                    <input type="number" step="0.01" id="min_price" name="min_price" class="form-control" value="<?php echo htmlspecialchars($_GET['min_price'] ?? ''); ?>" />
                </div>
                <div class="col-md-4">
                    <label for="max_price" class="form-label">Max Price (OMR):</label>
                    <input type="number" step="0.01" id="max_price" name="max_price" class="form-control" value="<?php echo htmlspecialchars($_GET['max_price'] ?? ''); ?>" />
                </div>
                <div class="col-md-4 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100">Search</button>
                </div>
            </div>
        </form>

        <?php
        $results = [];
        $errors = [];

        // Check if there is a search submission
        if ($_SERVER["REQUEST_METHOD"] == "GET" && (!empty($_GET['search_name']) || !empty($_GET['search_category']) || !empty($_GET['min_price']) || !empty($_GET['max_price']))) {
            $sql = "SELECT * FROM products WHERE 1=1";
            $params = [];

            if (!empty($_GET['search_name'])) {
                $sql .= " AND name LIKE :name";
                $params[':name'] = '%' . $_GET['search_name'] . '%';
            }

            if (!empty($_GET['search_category'])) {
                $sql .= " AND category LIKE :category";
                $params[':category'] = '%' . $_GET['search_category'] . '%';
            }

            if (!empty($_GET['min_price'])) {
                if (is_numeric($_GET['min_price'])) {
                    $sql .= " AND price >= :min_price";
                    $params[':min_price'] = (float)$_GET['min_price'];
                } else {
                    $errors[] = "Minimum price must be a number.";
                }
            }

            if (!empty($_GET['max_price'])) {
                if (is_numeric($_GET['max_price'])) {
                    $sql .= " AND price <= :max_price";
                    $params[':max_price'] = (float)$_GET['max_price'];
                } else {
                    $errors[] = "Maximum price must be a number.";
                }
            }
            
            if (isset($_GET['min_price']) && isset($_GET['max_price']) && is_numeric($_GET['min_price']) && is_numeric($_GET['max_price']) && (float)$_GET['min_price'] > (float)$_GET['max_price']){
                 $errors[] = "Minimum price cannot be greater than maximum price.";
            }

            if (empty($errors)) {
                try {
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute($params);
                    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
                } catch (PDOException $e) {
                    $errors[] = "Database query failed: " . $e->getMessage();
                }
            }
        }

        if (!empty($errors)):
        ?>
            <div class="alert alert-danger">
                <?php foreach ($errors as $error): ?>
                    <p><?php echo htmlspecialchars($error); ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if ($_SERVER["REQUEST_METHOD"] == "GET" && empty($errors) && isset($results)): ?>
            <h3 class="mt-5">Search Results:</h3>
            <?php if (count($results) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead class="table-light">
                            <tr>
                                <th>ID</th>
                                <th>Image</th>
                                <th>Name</th>
                                <th>Category</th>
                                <th>Description</th>
                                <th>Price (OMR)</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($results as $row): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['id']); ?></td>
                                    <td><img src="../../<?php echo htmlspecialchars($row['image_url']); ?>" alt="<?php echo htmlspecialchars($row['name']); ?>" /></td>
                                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['category']); ?></td>
                                    <td><?php echo htmlspecialchars($row['description']); ?></td>
                                    <td><?php echo htmlspecialchars(number_format($row['price'], 2)); ?></td>
                                    <td><a href="update_product_form.php?id=<?php echo htmlspecialchars($row['id']); ?>" class="btn btn-sm btn-warning">Update</a></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="alert alert-info">No products found matching your criteria.</p>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
