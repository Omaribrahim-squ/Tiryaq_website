<?php 
require_once 'db_config.php'; 
$products = [];
$error = '';

try {
    $stmt = $pdo->query("SELECT id, name, category, price FROM products ORDER BY name ASC");
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>Select Product to Update - Tiryaq Pharmacy Backend</title>
    <!-- Bootstrap CSS for styling -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style type="text/css">
        body { 
            padding-top: 70px; /* Adjust for fixed navbar */ 
            font-family: Arial, sans-serif;
        }
        .container { max-width: 900px; }
        .navbar-brand { font-weight: bold; }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="../../products.html">Tiryaq Pharmacy (Frontend)</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavBackend" aria-controls="navbarNavBackend" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavBackend">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="search.php">Search Products</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="insert_product.php">Add Product</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="update_product_selection.php">Update Product</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <h2 class="text-center mb-4">Select Product to Update</h2>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if (empty($products) && empty($error)): ?>
            <div class="alert alert-info">No products found in the database. <a href="insert_product.php">Add a product first.</a></div>
        <?php elseif (!empty($products)): ?>
            <div class="list-group">
                <?php foreach ($products as $product): ?>
                    <a href="update_product_form.php?id=<?php echo htmlspecialchars($product['id']); ?>" class="list-group-item list-group-item-action">
                        <strong><?php echo htmlspecialchars($product['name']); ?></strong> 
                        (Category: <?php echo htmlspecialchars($product['category'] ?? 'N/A'); ?>) - 
                        Price: <?php echo htmlspecialchars(number_format($product['price'], 2)); ?> OMR
                    </a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
