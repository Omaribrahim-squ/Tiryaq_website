<?php
// /home/ubuntu/tiryaq_pharmacy/backend/php/product_admin_handler.php
require_once 'db_config.php';

session_start(); // Though not strictly for admin, good practice if any user context were needed.

header('Content-Type: application/json');
$action = $_POST['action'] ?? $_GET['action'] ?? null;
$response = ['success' => false, 'message' => 'Invalid admin action.'];

// Ensure PDO connection is available
if (!$pdo) {
    $response['message'] = 'Database connection failed.';
    echo json_encode($response);
    exit;
}

switch ($action) {
    case 'add_product':
        $name = trim($_POST['name'] ?? '');
        $category = trim($_POST['category'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $price = trim($_POST['price'] ?? '');
        $image_url = trim($_POST['image_url'] ?? '');

        if (empty($name) || empty($price) || empty($image_url)) {
            $response['message'] = 'Name, Price, and Image URL are required fields.';
        } elseif (!is_numeric($price) || $price < 0) {
            $response['message'] = 'Price must be a non-negative number.';
        } elseif (!preg_match('/^(images\/)?[a-zA-Z0-9_\-\.]+\.(png|jpg|jpeg|gif|webp)$/i', $image_url)) {
            $response['message'] = 'Image URL must be a valid image file path (e.g., images/image.png or image.jpg).';
        } else {
            try {
                $sql = "INSERT INTO products (name, category, description, price, image_url) VALUES (:name, :category, :description, :price, :image_url)";
                $stmt = $pdo->prepare($sql);
                $stmt->bindParam(':name', $name);
                $stmt->bindParam(':category', $category);
                $stmt->bindParam(':description', $description);
                $stmt->bindParam(':price', $price);
                $stmt->bindParam(':image_url', $image_url);
                $stmt->execute();
                $response = ['success' => true, 'message' => 'Product added successfully.', 'product_id' => $pdo->lastInsertId()];
            } catch (PDOException $e) {
                $response['message'] = 'Database error adding product: ' . $e->getMessage();
            }
        }
        break;

    case 'search_products':
        $search_term = trim($_GET['search_term'] ?? '');
        $search_category = trim($_GET['search_category'] ?? '');
        $min_price = trim($_GET['min_price'] ?? '');
        $max_price = trim($_GET['max_price'] ?? '');

        $sql = "SELECT * FROM products WHERE 1=1";
        $params = [];

        if (!empty($search_term)) {
            $sql .= " AND (name LIKE :term OR description LIKE :term)";
            $params[':term'] = '%' . $search_term . '%';
        }
        if (!empty($search_category)) {
            $sql .= " AND category LIKE :category";
            $params[':category'] = '%' . $search_category . '%';
        }
        if (!empty($min_price) && is_numeric($min_price)) {
            $sql .= " AND price >= :min_price";
            $params[':min_price'] = $min_price;
        }
        if (!empty($max_price) && is_numeric($max_price)) {
            $sql .= " AND price <= :max_price";
            $params[':max_price'] = $max_price;
        }
        $sql .= " ORDER BY name ASC";

        try {
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $response = ['success' => true, 'message' => 'Products fetched.', 'products' => $products];
        } catch (PDOException $e) {
            $response['message'] = 'Database error searching products: ' . $e->getMessage();
        }
        break;

    case 'delete_product':
        $product_id = filter_var($_POST['product_id'] ?? null, FILTER_VALIDATE_INT);
        if ($product_id) {
            try {
                // First, check if product exists
                $stmt_check = $pdo->prepare("SELECT id FROM products WHERE id = :id");
                $stmt_check->bindParam(':id', $product_id, PDO::PARAM_INT);
                $stmt_check->execute();
                if ($stmt_check->fetch()) {
                    $stmt_delete = $pdo->prepare("DELETE FROM products WHERE id = :id");
                    $stmt_delete->bindParam(':id', $product_id, PDO::PARAM_INT);
                    $stmt_delete->execute();
                    if ($stmt_delete->rowCount() > 0) {
                        $response = ['success' => true, 'message' => 'Product deleted successfully.'];
                    } else {
                        $response['message'] = 'Product could not be deleted or was already deleted.';
                    }
                } else {
                    $response['message'] = 'Product not found for deletion.';
                }
            } catch (PDOException $e) {
                $response['message'] = 'Database error deleting product: ' . $e->getMessage();
            }
        } else {
            $response['message'] = 'Invalid Product ID for deletion.';
        }
        break;

    default:
        // Response already set to 'Invalid admin action.'
        break;
}

echo json_encode($response);
exit;
?>
