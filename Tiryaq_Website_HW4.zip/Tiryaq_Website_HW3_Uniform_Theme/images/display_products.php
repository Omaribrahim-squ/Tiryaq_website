
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Product List</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
  <h2 class="text-center mb-4">List of Products</h2>
  <?php
    // 1. Define Product class
    class Product {
      public $id;
      public $name;
      public $price;
      public $description;

      function __construct($id, $name, $price, $description) {
        $this->id = $id;
        $this->name = $name;
        $this->price = $price;
        $this->description = $description;
      }
    }

    // 2. Create DB connection
    $conn = mysqli_connect("localhost", "root", "", "tiryaq_pharmacy");

    // 3. Check connection
    if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
    }

    // 4. Retrieve data from Product table
    $sql = "SELECT * FROM Product";
    $result = mysqli_query($conn, $sql);

    // 5. Create array of Product objects
    $products = array();
    if (mysqli_num_rows($result) > 0) {
      while ($row = mysqli_fetch_assoc($result)) {
        $p = new Product($row["id"], $row["product_name"], $row["price"], $row["description"]);
        $products[] = $p;
      }
    } else {
      echo "<p class='text-danger'>No products found.</p>";
    }

    // 6. Display products in a table
    if (count($products) > 0) {
      echo "<table class='table table-bordered'>";
      echo "<thead><tr><th>ID</th><th>Product Name</th><th>Price (OMR)</th><th>Description</th></tr></thead><tbody>";
      foreach ($products as $prod) {
        echo "<tr>";
        echo "<td>{$prod->id}</td>";
        echo "<td>{$prod->name}</td>";
        echo "<td>{$prod->price}</td>";
        echo "<td>{$prod->description}</td>";
        echo "</tr>";
      }
      echo "</tbody></table>";
    }

    // 7. Close connection
    mysqli_close($conn);
  ?>
</div>
</body>
</html>
